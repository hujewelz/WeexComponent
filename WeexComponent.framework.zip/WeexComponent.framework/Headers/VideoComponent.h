//
//  VideoComponent.h
//  xiaoDian
//
//  Created by huluobo on 2018/4/21.
//

#import <Foundation/Foundation.h>
#import <WeexSDK/WeexSDK.h>

@interface VideoComponent : WXComponent

@end
